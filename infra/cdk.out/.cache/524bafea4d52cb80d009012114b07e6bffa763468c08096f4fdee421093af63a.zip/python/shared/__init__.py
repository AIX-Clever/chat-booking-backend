"""Shared package"""

__version__ = '1.0.0'

from . import domain
from . import infrastructure
from . import utils
# Force update 2025-12-13
